# -*- coding: utf-8 -*-

import pandas as pd
import csv


def simple_test_char_filter(char_filter):

    file = "test/char_filter.csv"
    correct = 0
    for input, expected in __iterate(file):
        output = char_filter(input)
        if output == expected:
            correct += 1
        else:
            print("error! input string was: {}\nexpected output was: {}\ngiven output was:{}".format(input, expected, output))
            print("{} tests passed up to this point".format(correct))
            return
    print("All test succeeded - well done !")


def __iterate(file):
    df = pd.read_csv(file, sep=";", quoting=csv.QUOTE_ALL)
    for elt in df.iterrows():
        yield (elt[1][0], elt[1][1])